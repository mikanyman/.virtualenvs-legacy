"""Create your XML Element Processors here."""

PIXELISE_PATTERNS = {
     'div': 'div',
}

def div(element, state, context):
    """Div elements are common, but not required."""
    if state == 'begin':
        # Do something
        pass

    if state == 'end':
        # Do something
        pass

